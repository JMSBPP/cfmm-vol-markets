# Summary of changes for run 8011be2a-03e0-4fa6-870e-973f9b81fad4
I turned the design question into a machine-checked mathematical backbone plus an EVM design-space analysis. Everything is committed and pushed.

## What was found first (a correction)
The informal "admissibility" claim — that `d ∈ [0,1]` implies `Σ Qᵥⁱ·d(p_risk,p(i)) = Σ Qᵥⁱ` — is **false**. Being valued in `[0,1]` only gives an inequality; equality forces `d ≡ 1`. I formalized both the true facts and an explicit counterexample.

## Formal results (`RequestProject/Main.lean`, builds with no `sorry`, no warnings)
- `discounted_nonneg` : `0 ≤ Σ Qᵥⁱ·dᵢ`.
- `discounted_le_total` : `Σ Qᵥⁱ·dᵢ ≤ Σ Qᵥⁱ` (= the accounting identity `Qᵥ^Σ`) when `d ≤ 1`, `Qᵥⁱ ≥ 0`.
- `discounted_eq_total_iff` : equality holds iff termwise `Qᵥⁱ·dᵢ = Qᵥⁱ`.
- `discounted_eq_total_iff_pos` : with `Qᵥⁱ > 0`, equality holds iff `dᵢ = 1` for all i.
- `discounted_claim_counterexample` : an explicit instance (`N=1, Qᵥ≡1, d≡0`) where the stated identity fails.
- `admissible_iff_mul` : the division-free EVM reformulation of the admissible region, `Δ ≤ Q_M^Σ/p_risk ⟺ Δ·p_risk ≤ Q_M^Σ` (for `p_risk > 0`).
- `admissible_state_bounds` : a nonnegative admissible flow keeps the post-update state in `[Qᵥ^Σ, Qᵥ^Σ + Q_M^Σ/p_risk]`.

## Answers to the two design questions (`DESIGN_SPACE.md`)
- **Representation for `d`:** since `d ∈ [0,1]` and its inputs `p(i(σ_x96))`, `p_risk` are already X96, store `d` as unsigned `Q0.96`/X96 (scale `2^96`, clamp `≤ 2^96`). The discount `Qᵥ·d` then becomes an exact right-shift `>>96` (no rounding division), stays base-consistent with the price side, and preserves the proved invariant `Σ Qᵥⁱ·dᵢ ∈ [0, Σ Qᵥⁱ]`. WAD/RAY are acceptable but cost a base change and a true `mulDiv`; signed/float and any unclamped `>1` format are rejected.
- **Design space for `∂_(M,v)` (the flow `Δ`):** carry it in RAY (`1e27`) to match the state accumulator; it is nonnegative and upper-bounded, so an unsigned RAY slot suffices. Compute `Q_M^Σ/p_risk` as a single fused `mulDiv` rounding **down**, and enforce admissibility via the cross-multiplied guard `Δ·p_risk ≤ Q_M^Σ` to avoid a rounding division (both properties are the proved `admissible_iff_mul` / `admissible_state_bounds`).

The document maps each recommendation to the corresponding verified lemma and includes the fixed-point conventions (X96 = `2^96`, WAD = `1e18`, RAY = `1e27`).