# `tbd.md` — flow module `(ΔQ_M, p_risk) → (ΔQ_M, ΔQ_v)`

Machine-checked backbone: `RequestProject/Flow.lean` (§1) and
`RequestProject/Main.lean` (admissible region), both build with **no `sorry`**.

## 1. The map

The `∂_(M,v)` operator turns an exogenous money inflow `ΔQ_M` into a share flow
at the (exogenous) risk price `p_risk`:

* `ΔQ_v = ΔQ_M / p_risk`  — `Flow.deltaShares`.

Properties:

* nonnegativity `0 ≤ ΔQ_v` for `ΔQ_M ≥ 0`, `p_risk > 0` (`deltaShares_nonneg`);
* monotone in the inflow (`deltaShares_mono`);
* **admissible region collapses to a clean money ceiling**: for `p_risk > 0`,

  `ΔQ_v ≤ Q_M^Σ / p_risk  ⟺  ΔQ_M ≤ Q_M^Σ`   (`deltaShares_admissible_iff`).

  So the admissible money interval is exactly `[0, Q_M^Σ]` with `X := Q_M^Σ`.

The state-side facts (division-free guard and post-update bounds) are in
`Main.lean`:

* `admissible_iff_mul` : `Δ ≤ Q_M^Σ / p_risk ⟺ Δ·p_risk ≤ Q_M^Σ` (no division);
* `admissible_state_bounds` : the post-update state stays in
  `[Q_v^Σ, Q_v^Σ + Q_M^Σ / p_risk]`.

## 2. EVM representation

| Object   | Base | Slot | Rationale |
|----------|------|------|-----------|
| `ΔQ_M`   | RAY (`1e27`) or token WAD, unsigned | `uint256` | exogenous inflow, one-sided |
| `p_risk` | Q64.96 (`2^96`), unsigned, exogenous | `uint160` | comparable to `p(i)` |
| `ΔQ_v`   | RAY (`1e27`), unsigned | `uint256` | matches the state accumulator |

* Compute `ΔQ_v = ΔQ_M / p_risk` as a **single fused `mulDiv`** (`mulDiv(ΔQ_M,
  2^96, p_risk)` if `ΔQ_M` is X96-comparable, else with the RAY/WAD scale), so the
  intermediate is never truncated before the divide. Round **down** (conservative
  for the deposits backing shares).
* Enforce admissibility with the **cross-multiplied, division-free guard**
  `ΔQ_v · p_risk ≤ Q_M^Σ` (`admissible_iff_mul`), equivalently the money-side test
  `ΔQ_M ≤ Q_M^Σ` (`deltaShares_admissible_iff`). Prefer the money-side test: it is
  a plain comparison, no multiplication or division at all.
* `ΔQ_v` is nonnegative and upper-bounded, so an **unsigned** RAY slot suffices;
  promote to signed `int256` only if `∂_(M,v)` is ever made bidirectional M↔v.

## Output

`(ΔQ_M, p_risk) → (ΔQ_M, ΔQ_v)` with `ΔQ_v = ΔQ_M / p_risk`, admissible iff
`ΔQ_M ≤ Q_M^Σ`. Consumed together with `pos_spec.md` by `getLiquidityForAmounts`
(see `SCHEDULE.md`).
