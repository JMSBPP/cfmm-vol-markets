# `pos_spec.md` — position spec module `(σ̄, #_σ̄, s_v) → (p(i), p(i_l), p(i_u))`

Machine-checked backbone: `RequestProject/PosSpec.lean` (builds with **no `sorry`**,
only the standard axioms `propext`, `Classical.choice`, `Quot.sound`).

## 1. Inputs and EVM representations

| Symbol            | Meaning                     | EVM type | Notes |
|-------------------|-----------------------------|----------|-------|
| `σ(t)`            | realized tick volatility    | `u88`    | observed |
| `i_μ(t)`          | mean tick                   | `i24`    | observed |
| `σ̄`              | target volatility           | `u88`    | user reveal |
| `σ̄₉₆`            | `σ̄` lifted to Q64.96        | `uint160`| `σ̄ · 2^96` |
| `s_v`             | skew ∈ [0,1]                | `u16`    | fraction: store `s_v · 2^16`, invariant `≤ 2^16` |
| `#_σ̄(Δ_i)`       | width in tick-spacing units | `u24`    | integer count |
| `i_l, i_u, i`     | tick coordinates            | `i24`    | signed ticks |
| `p(i), p(i_l), p(i_u)` | price coordinates      | `Q64.96` (`uint160`) | sqrt-price grid |

## 2. The map (as formalized)

* **Skew interpolation** `i(σ̄₉₆) = s_v·i_l + (1 - s_v)·i_u`
  — `PosSpec.skewTick`.
  * endpoints: `skewTick 1 = i_l` (`skewTick_one`), `skewTick 0 = i_u`
    (`skewTick_zero`).
  * convexity: for `s_v ∈ [0,1]` and `i_l ≤ i_u`, `i_l ≤ i(σ̄) ≤ i_u`
    (`skewTick_mem`).
  * gaps: `i_u − i = s_v·(i_u − i_l)` (`skewTick_gap_upper`),
    `i − i_l = (1 − s_v)·(i_u − i_l)` (`skewTick_gap_lower`).
* **Width relation** `Δ_i · #_σ̄ = |i_l − i_u|` gives the oriented span
  `i_u − i_l = Δ_i · #_σ̄` when `i_l ≤ i_u` (`width_span`). Combined with the gaps,
  `i_u − i = s_v·Δ_i·#_σ̄` and `i − i_l = (1 − s_v)·Δ_i·#_σ̄`.
* **Price coordinate** `p(i) = λ^{(i/2)·Δ_i}`, `λ = 1.0001` (`PosSpec.tickPrice`,
  `PosSpec.lam`).
  * positivity `0 < p(i)` (`tickPrice_pos`);
  * monotone `i ≤ j ⟹ p(i) ≤ p(j)` (`tickPrice_le`) and strict
    (`tickPrice_lt`) for `Δ_i > 0`;
  * **price ordering induced by the skew** `p(i_l) ≤ p(i(σ̄)) ≤ p(i_u)`
    (`tickPrice_skew_mem`) — this is the invariant the downstream liquidity /
    payoff step relies on.

## 3. EVM design notes

* `s_v` is a `u16` fraction: store `ŝ = s_v · 2^16`, invariant `0 ≤ ŝ ≤ 2^16`, so
  the interpolation is `i = (ŝ·i_l + (2^16 − ŝ)·i_u) >> 16` (division-free, a
  right shift). Because `i` is a convex combination it never leaves `[i_l, i_u]`
  (`skewTick_mem`), so the `i24` result cannot overflow the endpoints.
* The tick grid is native Uniswap-v3: prices are `sqrtRatioX96`. Use
  `TickMath.getSqrtRatioAtTick` for `p(i_l)`, `p(i_u)`; the interpolated
  `p(i(σ̄))` is likewise `TickMath.getSqrtRatioAtTick(i)`. Monotonicity of that
  table is exactly `tickPrice_lt`, so the ordering `p_a = p(i_l) < p_b = p(i_u)`
  needed by `getLiquidityForAmounts` is guaranteed by construction.
* Width `#_σ̄` as `u24` times spacing `Δ_i` reproduces `i_u − i_l` exactly
  (`width_span`); no rounding is introduced by the width leg.

## Output

`(σ̄, #_σ̄, s_v) → (p(i(σ̄)), p(i_l), p(i_u))` with the guaranteed ordering
`p(i_l) ≤ p(i(σ̄)) ≤ p(i_u)`, consumed by `tbd.md` and by
`getLiquidityForAmounts`.
