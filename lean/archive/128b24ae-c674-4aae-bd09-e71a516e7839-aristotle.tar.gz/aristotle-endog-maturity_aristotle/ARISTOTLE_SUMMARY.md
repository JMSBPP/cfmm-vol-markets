# Summary of changes for run 311f81e5-6960-45c2-a822-0eb46d7cb10c
Created `RequestProject/EndogenousMaturity.lean` without modifying any of the 10 existing Lean files. The new module formalizes endogenous maturity, the decided auto-deleverage law, conservative real-layer rounding, and three explicitly non-canonical joint-recalibration candidates. `lake build` succeeds, the file contains no `sorry`, `admit`, new axioms, or `implemented_by`, and representative theorem checks use only `propext`, `Classical.choice`, and `Quot.sound`.

Definitions added:
- `tStar`, `dQvStarOfMaturity`: derived maturity and its inverse representation.
- `dMReq`, `dQvFunded`, `tStarFunded`: required collateral, funded exposure, and recalibrated maturity.
- `tStarJointMult`, `tStarJointSub`, `tStarJointQuadratic`: three clearly documented candidates pending author decision; no joint law is selected.

Theorems added (one-line claims):
- `dQvStarOfMaturity_tStar`: the inverse representation recovers `dQvStar` when `Nσ ≠ 0`.
- `tStar_dQvStarOfMaturity`: deriving maturity from its inverse representation recovers `t` when `Nσ ≠ 0`.
- `maturity_equivalence`: proves `dQvStar = (tStar / 2) * Nσ` when `Nσ ≠ 0`.
- `variancePortfolio_upsilon_at_tStar`: the dated variance portfolio at derived maturity has vega `dQvStar / Nσ` for a nonzero finite-difference step.
- `tStar_variancePortfolio_upsilon`: the `Nσ`-scaled dated portfolio at derived maturity has vega `dQvStar` when `Nσ` and the finite-difference step are nonzero.
- `tStar_unit_upsilon`: multiplying the proven `(2/t)` unit-vega portfolio by `dQvStar` gives vega `dQvStar`; target, notional, and finite-difference step are nonzero.
- `tStar_pos`: positive target vega and positive `Nσ` imply positive maturity.
- `tStar_strictMono_dQvStar`: maturity is strictly increasing in target vega for fixed positive `Nσ`.
- `tStar_strictAnti_Nσ`: maturity is strictly decreasing over positive `Nσ` for fixed positive target vega.
- `dQvFunded_admissible`: funded exposure never exceeds `QM / prisk`.
- `dQvFunded_admissible_iff_mul`: quotient admissibility is equivalent to the division-free invariant when `prisk > 0`.
- `dQvFunded_mul_le_of_violation`: under a violation and `prisk > 0`, funded exposure satisfies `dQvFunded * prisk ≤ QM`.
- `dQvFunded_eq_of_no_violation`: when `dQvStar * prisk ≤ QM` and `prisk > 0`, exposure is untouched.
- `dQvFunded_maximal`: every nonnegative, target-bounded, admissible exposure is at most `dQvFunded`, for `prisk > 0`.
- `tStarFunded_mono_QM`: funded maturity is monotone in `QM` when `prisk > 0` and `Nσ > 0`.
- `tStarFunded_antitone_prisk`: funded maturity is antitone over positive risk prices when `QM ≥ 0` and `Nσ > 0`.
- `tStarFunded_eq_tStar_of_topup`: sufficient collateral restores full target maturity when `prisk > 0`.
- `dQvFunded_zero_QM`: zero collateral gives zero funded exposure for nonnegative target exposure; the requested `prisk > 0` condition is retained although totalized real division makes it unnecessary for this equality alone.
- `tStarFunded_zero_QM`: zero collateral consequently gives zero funded maturity.
- `dQvFunded_roundDown`: rounding the quotient cap downward can only reduce funded exposure.
- `roundDown_preserves_invariant`: a downward-rounded cap preserves the division-free collateral invariant when `prisk > 0`.
- `tStarJointMult_nonneg`: the multiplicative candidate is nonnegative for nonnegative funded maturity.
- `tStarJointMult_antitone`: the multiplicative candidate contracts monotonically in realized variance when `sig2K > 0` and funded maturity is nonnegative.
- `tStarJointMult_zero`: the multiplicative candidate agrees with funded maturity at zero realized variance.
- `tStarJointMult_exhausted`: the multiplicative candidate reaches zero at `sig2R = sig2K` when `sig2K ≠ 0`.
- `tStarJointSub_nonneg`: the subtractive candidate is nonnegative by construction.
- `tStarJointSub_antitone`: the subtractive candidate contracts monotonically in realized variance when `sig2K > 0` and funded maturity is nonnegative.
- `tStarJointSub_zero`: the subtractive candidate agrees with funded maturity at zero realized variance when funded maturity is nonnegative.
- `tStarJointSub_exhausted`: the subtractive candidate reaches zero at exhaustion when `sig2K ≠ 0`.
- `tStarJointQuadratic_nonneg`: the quadratic candidate is nonnegative for nonnegative funded maturity.
- `tStarJointQuadratic_antitone`: over nonnegative realized variance, the quadratic candidate contracts monotonically when `sig2K > 0` and funded maturity is nonnegative.
- `tStarJointQuadratic_zero`: the quadratic candidate agrees with funded maturity at zero realized variance.
- `tStarJointQuadratic_exhausted`: the quadratic candidate reaches zero at exhaustion when `sig2K ≠ 0`.
- `joint_candidates_disagree`: an explicit numeral instance proves the multiplicative and quadratic candidates differ, demonstrating that the pending author decision is substantive.

All necessary positivity, nonzero-denominator, nonnegativity, and domain restrictions are stated in theorem hypotheses and documented alongside the relevant declarations.